package com.harindra.iptvpro.vod

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView

/**
 * RAM PLAYER v23.0 ADD-ON 2 — Controlled Secondary Fallback Adapter (`Media3FallbackVodEngine`).
 *
 * Implements [VodPlayerEngine] using the project's existing Media3 1.11.1 dependency (zero new
 * libraries). Used ONLY when:
 * 1. Primary [LibVlcVodPlayerEngine] fails to initialize or hits an unrecoverable engine error, OR
 * 2. User explicitly selects "Media3 Fallback" in Video & Engine Settings.
 *
 * Strictly guarantees only ONE decoder is active at any time (managed by [VodEngineCoordinator]).
 */
@OptIn(UnstableApi::class)
class Media3FallbackVodEngine(
    private val context: Context,
    private val prefs: VodPreferencesStore
) : VodPlayerEngine {

    override val engineName: String = "Media3 1.11.1 Fallback Engine"

    private var manager: VodPlaybackManager? = null
    private var trackManager = VodTrackSelectionManager()
    private var attachedView: PlayerView? = null
    private var callbacks: VodEngineCallbacks? = null
    private var activeAspect: VodAspectRatioMode = VodAspectRatioMode.FIT

    override fun initialize(decoderMode: VodDecoderMode, bufferProfile: VodBufferProfile) {
        if (manager == null) {
            manager = VodPlaybackManager(context.applicationContext, prefs)
        }
        val player = manager!!.getOrCreatePlayer()
        player.removeListener(playerListener)
        player.addListener(playerListener)
        attachedView?.player = player
    }

    fun attachPlayerView(view: PlayerView) {
        attachedView = view
        manager?.getPlayer()?.let { view.player = it }
        manager?.applyAspectRatio(view, activeAspect)
    }

    fun detachPlayerView() {
        attachedView?.player = null
        attachedView = null
    }

    override fun setCallbacks(callbacks: VodEngineCallbacks?) {
        this.callbacks = callbacks
    }

    override fun loadMedia(
        streamUrl: String,
        resumePositionMs: Long,
        externalSubtitleUrl: String,
        headers: Map<String, String>
    ): Boolean {
        if (manager == null) initialize(VodDecoderMode.AUTO_HW_FALLBACK, VodBufferProfile.CINEMA_BALANCED)
        callbacks?.onOpening()
        return manager?.prepareMedia(streamUrl, resumePositionMs, externalSubtitleUrl) == true
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> callbacks?.onBuffering((manager?.getPlayer()?.bufferedPercentage ?: 0).toFloat())
                Player.STATE_READY -> {
                    callbacks?.onLengthChanged(getDurationMs())
                    if (manager?.getPlayer()?.isPlaying == true) callbacks?.onPlaying() else callbacks?.onPaused()
                }
                Player.STATE_ENDED -> callbacks?.onEnded()
                else -> {}
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) callbacks?.onPlaying() else callbacks?.onPaused()
        }

        override fun onTracksChanged(tracks: Tracks) {
            callbacks?.onTracksUpdated()
        }

        override fun onPlayerError(error: PlaybackException) {
            callbacks?.onError(error.message ?: error.errorCodeName)
        }
    }

    override fun play() { manager?.resume() }
    override fun pause() { manager?.pause() }
    override fun stop() { manager?.getPlayer()?.stop() }
    override fun isPlaying(): Boolean = manager?.getPlayer()?.isPlaying == true
    override fun isSeekable(): Boolean = manager?.getPlayer()?.isCurrentMediaItemSeekable == true
    override fun getPositionMs(): Long = manager?.getPlayer()?.currentPosition?.coerceAtLeast(0L) ?: 0L
    override fun getDurationMs(): Long {
        val d = manager?.getPlayer()?.duration ?: C.TIME_UNSET
        return if (d > 0L && d != C.TIME_UNSET) d else 0L
    }
    override fun getBufferedPercent(): Float = (manager?.getPlayer()?.bufferedPercentage ?: 0).toFloat()
    override fun seekTo(positionMs: Long) { manager?.getPlayer()?.seekTo(positionMs.coerceAtLeast(0L)) }
    override fun setPlaybackSpeed(rate: Float) { manager?.getPlayer()?.setPlaybackSpeed(rate.coerceIn(0.5f, 2.0f)) }
    override fun getPlaybackSpeed(): Float = manager?.getPlayer()?.playbackParameters?.speed ?: 1.0f
    override fun setVolumePercent(percent: Int) {
        val norm = (percent.coerceIn(0, 100)) / 100f
        manager?.getPlayer()?.volume = norm
    }
    override fun getVolumePercent(): Int = ((manager?.getPlayer()?.volume ?: 1f) * 100f).toInt()
    override fun setAudioDelayMs(delayMs: Long) {
        manager?.audioDelayProcessor?.setDelayMs(delayMs.toInt().coerceIn(0, 500))
    }
    override fun getAudioDelayMs(): Long = (manager?.audioDelayProcessor?.getDelayMs() ?: 0).toLong()
    override fun setSubtitleDelayMs(delayMs: Long) { /* Media3 does not support native subtitle offset */ }
    override fun getSubtitleDelayMs(): Long = 0L

    override fun getAudioTracks(): List<VodEngineTrack> {
        val p = manager?.getPlayer() ?: return emptyList()
        return trackManager.inspectAudioTracks(p).mapIndexed { idx, opt ->
            VodEngineTrack(id = idx, name = opt.label, isSelected = opt.isSelected, isOffOption = false)
        }
    }

    override fun selectAudioTrack(trackId: Int): Boolean {
        val p = manager?.getPlayer() ?: return false
        val opt = trackManager.inspectAudioTracks(p).getOrNull(trackId) ?: return false
        return trackManager.selectAudioTrack(p, opt)
    }

    override fun getSubtitleTracks(): List<VodEngineTrack> {
        val p = manager?.getPlayer() ?: return emptyList()
        return trackManager.inspectSubtitleTracks(p).mapIndexed { idx, opt ->
            VodEngineTrack(id = if (opt.isOff) -1 else idx, name = opt.label, isSelected = opt.isSelected, isOffOption = opt.isOff)
        }
    }

    override fun selectSubtitleTrack(trackId: Int): Boolean {
        val p = manager?.getPlayer() ?: return false
        val list = trackManager.inspectSubtitleTracks(p)
        val opt = if (trackId == -1) list.firstOrNull { it.isOff } else list.getOrNull(trackId)
        return opt != null && trackManager.selectSubtitleTrack(p, opt)
    }

    override fun addExternalSubtitle(subtitleUrl: String): Boolean = false

    override fun getVideoTracks(): List<VodEngineTrack> {
        val p = manager?.getPlayer() ?: return emptyList()
        return trackManager.inspectVideoQualities(p).options.mapIndexed { idx, opt ->
            VodEngineTrack(id = idx, name = opt.label, isSelected = opt.isSelected, isOffOption = false)
        }
    }

    override fun selectVideoTrack(trackId: Int): Boolean {
        val p = manager?.getPlayer() ?: return false
        val opt = trackManager.inspectVideoQualities(p).options.getOrNull(trackId) ?: return false
        return trackManager.selectVideoQuality(p, opt)
    }

    override fun getVideoInfo(): VodEngineVideoInfo {
        val vf = manager?.getPlayer()?.videoFormat
        return VodEngineVideoInfo(
            width = vf?.width ?: 0,
            height = vf?.height ?: 0,
            fps = vf?.frameRate ?: 0f,
            codec = vf?.sampleMimeType?.substringAfter('/')?.uppercase().orEmpty().ifBlank { "Media3" },
            bitrateBps = vf?.bitrate ?: 0,
            decoderModeLabel = "Media3 HW"
        )
    }

    override fun setAspectRatio(mode: VodAspectRatioMode) {
        activeAspect = mode
        attachedView?.let { manager?.applyAspectRatio(it, mode) }
    }

    override fun applyDialoguePreset(preset: VodDialoguePreset) {
        setVolumePercent(preset.volumePercent.coerceAtMost(100))
    }

    override fun release() {
        detachPlayerView()
        manager?.release()
        manager = null
    }
}

enum class VodEngineChoice(val id: String, val label: String) {
    LIBVLC_PRIMARY("LIBVLC", "LibVLC 3.6.5 (Primary)"),
    MEDIA3_FALLBACK("MEDIA3", "Media3 1.11.1 (Fallback)");

    fun opposite(): VodEngineChoice = if (this == LIBVLC_PRIMARY) MEDIA3_FALLBACK else LIBVLC_PRIMARY
}

/**
 * Guarantees strictly ONE active VOD engine at a time — releases previous engine cleanly
 * before activating fallback so low-RAM TVs never hold duplicate video decoders.
 */
class VodEngineCoordinator(
    private val primaryEngineFactory: () -> VodPlayerEngine,
    private val fallbackEngineFactory: () -> VodPlayerEngine
) {
    private var activeChoice: VodEngineChoice = VodEngineChoice.LIBVLC_PRIMARY
    private var activeEngine: VodPlayerEngine? = null
    private var hasAutoFallenBack: Boolean = false

    fun getActiveChoice(): VodEngineChoice = activeChoice

    fun getActiveEngine(): VodPlayerEngine? = activeEngine

    fun hasFallenBack(): Boolean = hasAutoFallenBack

    fun activate(
        choice: VodEngineChoice,
        decoderMode: VodDecoderMode,
        bufferProfile: VodBufferProfile,
        callbacks: VodEngineCallbacks?
    ): VodPlayerEngine {
        activeEngine?.setCallbacks(null)
        activeEngine?.release()
        activeEngine = null

        activeChoice = choice
        val engine = if (choice == VodEngineChoice.LIBVLC_PRIMARY) {
            primaryEngineFactory()
        } else {
            fallbackEngineFactory()
        }
        engine.initialize(decoderMode, bufferProfile)
        engine.setCallbacks(callbacks)
        activeEngine = engine
        return engine
    }

    fun tryControlledFallback(
        decoderMode: VodDecoderMode,
        bufferProfile: VodBufferProfile,
        callbacks: VodEngineCallbacks?
    ): VodPlayerEngine? {
        if (hasAutoFallenBack || activeChoice == VodEngineChoice.MEDIA3_FALLBACK) return null
        hasAutoFallenBack = true
        return activate(VodEngineChoice.MEDIA3_FALLBACK, decoderMode, bufferProfile, callbacks)
    }

    fun resetFallbackState() {
        hasAutoFallenBack = false
    }

    fun releaseAll() {
        activeEngine?.setCallbacks(null)
        activeEngine?.release()
        activeEngine = null
    }
}
